﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManishaConsole
{
    public class ArrayDemo
    {

        static void Main() {

            ArrayDemo obj = new ArrayDemo();
           // obj.OneDimensionalArray();
           // obj.TwoDimensionalArray();
           // obj.DemoSortArray();
            //obj.DemoReverseArray();
            obj.DemoForeachLoop();
            Console.ReadLine();
        
        }
        public void OneDimensionalArray() {

           // int r1, r2, r3, r4, r5;
            int[] arrayRollNo = new int[5];

            Console.WriteLine("Enter roll numbers:");
            for (int i = 0; i < arrayRollNo.Length; i++)
            {

                arrayRollNo[i] = Convert.ToInt32(Console.ReadLine());
            }

            Console.WriteLine("You have entered below roll numbers:");
            for (int i = 0; i < arrayRollNo.Length; i++)
            {
                Console.WriteLine(arrayRollNo[i]);
            }
        
        }

        public void TwoDimensionalArray()
        {

            // int r1, r2, r3, r4, r5;
            Console.WriteLine("enter the rows");
            int rowLength = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("enter the col");
            int colLength = Convert.ToInt32(Console.ReadLine());

            int[,] arrayRollNo = new int[rowLength,colLength];
            Console.WriteLine("Enter roll numbers:");
            for (int row = 0; row <arrayRollNo.GetLength(0) ; row++)
            {
                for (int col = 0; col < arrayRollNo.GetLength(1); col++)
                {
                    arrayRollNo[row, col] = Convert.ToInt32(Console.ReadLine());
                    
                }
            }

            Console.WriteLine("below are the  roll numbers:");
            for (int row = 0; row < arrayRollNo.GetLength(0); row++)
            {
                for (int col = 0; col < arrayRollNo.GetLength(1); col++)
                {
                    Console.WriteLine(arrayRollNo[row, col]);
                }
            }

            //print in tabular--+
            

        }

        public void DemoSortArray() {

            //int[] arr = new int[5];
            int[] arr = { 8, 11, 4, 5, 26 };
            //4,5,11,26

            for (int i = 0; i < arr.Length; i++)
            {
                Console.WriteLine(arr[i]);
            }

            Console.WriteLine("After sorting");
            Array.Sort(arr);
            for (int i = 0; i < arr.Length; i++)
            {
                Console.WriteLine(arr[i]);
            }
        
        }

        public void DemoReverseArray()
        {

            //int[] arr = new int[5];
            int[] arr = { 8, 11, 4, 5, 26 };
            //4,5,11,26

            for (int i = 0; i < arr.Length; i++)
            {
                Console.WriteLine(arr[i]);
            }

            Console.WriteLine("After reversing");
            Array.Reverse(arr);
            for (int i = 0; i < arr.Length; i++)
            {
                Console.WriteLine(arr[i]);
            }
            //descinding order ?
        }


        public void DemoForeachLoop()
        {

            //int[] arr = new int[5];
            int[] arr = { 8, 11, 4, 5, 26 };

            foreach (var item in arr)
            {
                Console.WriteLine(item);
            }
           
        }

        public void DemoForJaggedArray()
        {

          

        }
    }
}
