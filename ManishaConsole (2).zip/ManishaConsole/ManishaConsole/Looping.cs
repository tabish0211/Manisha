﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManishaConsole
{
   public class Looping
    {
       //static void Main()
       //{
       //    int i = 1;

       //    Looping obj = new Looping();
       //    //obj.DemoForLoop();
       //    //obj.DemoWhileLoop();
       //    //obj.DemoDoWhileLoop();
       //    obj.DemoToPrintSumofTheNumbers();
       //    Console.ReadLine();
       //}

       public void DemoForLoop() {

           //for (int i = 1; i <= 10; i++)
           //{
           //    Console.WriteLine(i);
           //}

           //for (int i = 1; i <= 10; i++)
           //{
           //    if (i==6)
           //    {
           //        //to come out of the loop
           //        break;
           //    }
           //    Console.WriteLine(i);
           //}

           for (int i = 1; i <= 10; i++)
           {
               if (i == 6)
               {
                   //to skip the below task
                   continue;
                  
               }
               Console.WriteLine(i);
           }
           Console.WriteLine("Hey loop exited");
       
       }

       public void DemoWhileLoop() {

           //int i = 1;
           //while (i<=10)
           //{

           //    Console.WriteLine(i);
           //    i++;
           //}

           char ch = 'Y';
           while (ch =='Y')
           {

               Console.WriteLine("*");
               Console.WriteLine("Do you want to continue, press Y/N");
               ch = Convert.ToChar(Console.ReadLine());
           }
           //implement break and continue in while loop

       }

       public void DemoDoWhileLoop() {

           int i = 1;
           do
           {
               Console.WriteLine(i);
               i++;
           } while (i<=10);

           //implement break and continue in do-while loop
       }

       public void DemoToPrintSumofTheNumbers()
       {
           Console.WriteLine("Enter number to print sum of the numbers");
           int number = Convert.ToInt32(Console.ReadLine());//2
           int sum = 0;
           for (int i = 1; i <=number; i++)
           {
               sum = sum + i;
           }

           Console.WriteLine(sum);
          

           //implement break and continue in do-while loop
       }
    }
}
