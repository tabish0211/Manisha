﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManishaConsole
{
    public class PropertiesDemo
    {

        public int Id { get; set; }
        public string Name { get; set; }
       // public Mysample mysample { get; set; }

       // private int _id;

       ////C# 2.0
       // public int ID
       // {
       //     get
       //     {
       //         return _id;
       //     }

       //     set
       //     {
       //         _id = value; ;
       //     }

       // }


        //public int get() {

        //    return _id;
        
        //}


        //public void set(int id)
        //{

        //    _id = id;

        //}
    }
}
