﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace ManishaConsole
//{
//    public class Constructor
//    {
//        //it is a special type of method whose name is same as that of class name
//        //it do not have any return type not even void
//        //it is used for instance varaibles initialization

//        public int Id { get; set; }
//        public string Name { get; set; }

//        //private int _id;
//        //public int Id
//        //{

//        //    get
//        //    {
//        //        return _id;
//        //    }

//        //    set
//        //    {
//        //        _id = value;

//        //    }
//        //}


//        //constructor overloading
//        public Constructor() {

//            Id = 1001;
//            Name = "Default Value";        
        
//        }

       
//        public Constructor(int id, string name)
//        {

//            Id = id;
//            Name = name;

//        }

//        public Constructor(string name,int id)
//        {

//            Id = id;
//            Name = name;

//        }

//        //why we dont have parametrized destructor
//        ~Constructor() {

//            Console.WriteLine("Hi I am destructor");
//            Console.ReadLine();
//        }

//    }

//    public class CallerConstructorCls
//    {

//        static void Main() {

//            //Constructor c = new Constructor();
//            //Console.WriteLine("Default values:your Id is :{0} and name is :{1}", c.Id, c.Name);

//            //Console.WriteLine("Enter Id");
//            //c.Id = Convert.ToInt32(Console.ReadLine());

//            //Console.WriteLine("Enter Name");
//            //c.Name = Console.ReadLine();

//            //Console.WriteLine("User Values:your Id is :{0} and name is :{1}",c.Id,c.Name);

//            Constructor c = new Constructor(1,"ABCD");
//            Console.WriteLine("Default values:your Id is :{0} and name is :{1}", c.Id, c.Name);

//            Console.WriteLine("Enter Id");
//            c.Id = Convert.ToInt32(Console.ReadLine());

//            Console.WriteLine("Enter Name");
//            c.Name = Console.ReadLine();

//            Console.WriteLine("User Values:your Id is :{0} and name is :{1}", c.Id, c.Name);
//            Console.ReadLine();
        
//        }

//    }
//}
