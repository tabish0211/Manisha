﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManishaConsole
{
    public class OrderOfConstructorAndDestructor
    {
        public int id;
        public OrderOfConstructorAndDestructor() {

            Console.WriteLine("I am base class");
        }

        ~OrderOfConstructorAndDestructor() {

            Console.WriteLine("I am destructor from parent");
            Console.ReadLine();
        
        }
    }

    public class A : OrderOfConstructorAndDestructor
    {
        public A() {
            Console.WriteLine(id);
            Console.WriteLine("I am derive class");
        }

        ~A() {

            

                Console.WriteLine("I am destructor from child");
                

            
        }

    }

    public class CallerClass {

        static void Main() {
            //Parent to child:constructor order
            // // child to parent:destructor order


            A obj = new A();
            Console.ReadLine();
        
        
        }
    
    }

}
