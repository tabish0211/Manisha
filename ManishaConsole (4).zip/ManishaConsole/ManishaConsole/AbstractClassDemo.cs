﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace ManishaConsole
//{
//    public abstract class AbstractClassDemo
//    {
//        public void CopyRights() {

//            Console.WriteLine("Its my definition you cant change");
        
//        }

//        public abstract void Discount();

//    }

//    public class AbstractUser : AbstractClassDemo {

//        public override void Discount()
//        {
//            Console.WriteLine("I am an abstarct overriden here");
//        }

    
//    }
  
    
//    public class Calls { 
    
//     static void Main()
//     {
//         AbstractUser obj = new AbstractUser();
//         obj.Discount();
//         obj.CopyRights();

//         AbstractClassDemo refc = new AbstractUser();
//         refc.Discount();
//         refc.CopyRights();

//        // AbstractClassDemo objdemo = new AbstractClassDemo();

//       Console.ReadLine();


//     }
//  }
//}
