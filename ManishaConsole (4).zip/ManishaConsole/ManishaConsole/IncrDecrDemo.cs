﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManishaConsole
{
   public class IncrDecrDemo
    {
       public void demo_PostIncr()
       {
           int x = 1;
           int y = x++ + x++;
           Console.WriteLine(x+" "+y);

       }

       public void demo_PreIncr()
       {
           int x = 1;
           int y = ++x + ++x;
           Console.WriteLine(x + " " + y);

       }
    }
}
