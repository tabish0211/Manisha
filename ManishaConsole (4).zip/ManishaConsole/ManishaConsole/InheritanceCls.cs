﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace ManishaConsole
//{
//    public class A
//    {
//        public int id;
//        public A(int id) {
//            this.id = id;
//            Console.WriteLine("I Am A");
        
//        }
//        public void A_Show() {

//            Console.WriteLine("Hi I am from A");
        
//        }
//    }

//    public class B : A
//    {
//        public B(int x,int y):base(y) {

//            Console.WriteLine("I Am B");
        
//        }

//    }

//    //public class C : B { 
    
//    ////A__B__C
    
//    //}
//    //multiple inheritance--not possible---to resolve it --interface
//    //public class D : A,B
//    //{

//    //    //A__B__C

//    //}

//    public class CallCls {


//        static void Main() {

//            B obj = new B(2,3);
//            obj.A_Show();
//            Console.ReadLine();
        
        
//        }
    
//    }

//}
