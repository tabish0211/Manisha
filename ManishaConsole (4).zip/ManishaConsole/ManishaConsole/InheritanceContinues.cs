﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace ManishaConsole
//{
//   public  class Custommer
//    {

//       public virtual void Discount() {

//           Console.WriteLine("10%");
//       }
//    }

//   public sealed class GoldCustomer : Custommer
//   {
//       //method overriridng 
//       public override void Discount() {

//           Console.WriteLine("15%");

//         }

//       public void GetName() { 
       
       
//       }

//   }

  

//   public class CallCls
//   {


//       static void Main()
//       {

//           //B obj = new B(2, 3);
//           //obj.A_Show();
//           //GoldCustomer gold = new GoldCustomer();
//           //gold.Discount();

//           //The base class reference can point to the derive class object
//           //Custommer cust = new GoldCustomer();
//           //cust.Discount();
           
//           Console.ReadLine();


//       }

//   }

//}
