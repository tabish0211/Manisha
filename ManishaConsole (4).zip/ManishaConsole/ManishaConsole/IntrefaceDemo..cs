﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManishaConsole
{
   public interface IntrefaceDemoDiscount
    {
       void Discount();
    }

   public interface IntrefaceDemoDiscountGold
   {
       void Discount();
   }

   public class ChildClass : IntrefaceDemoDiscount, IntrefaceDemoDiscountGold
   {
       
       void IntrefaceDemoDiscount.Discount()
       {
           Console.WriteLine("10%");
       }

       void IntrefaceDemoDiscountGold.Discount()
       {
           Console.WriteLine("20%");
       }
   }

   public class CallerCls {


       static void Main() {

           //ChildClass obj = new ChildClass();
           //obj.Discount();
          

           //IntrefaceDemoDiscount refc = new ChildClass();
           //refc.Discount();

           //IntrefaceDemoDiscountGold refcName = new ChildClass();
           //refcName.Discount();

           Object o = new object();
           int x = 1;
           o = x;//Boxing

           int y = (int)o;//Unboxing
           Console.WriteLine(y);

           Console.ReadLine();

       
       
       }
   }
}
