﻿
//using System;

//namespace ManishaConsole
//{
//    class Program
//    {
//        //static void Main(string[] args)
//        //{
//        //}

//        //static void Main()
//        //{
//        //    Console.WriteLine("Hello world");
//        //    Console.WriteLine("Bye");
//        //    //cw--press tabs
//        //    Console.WriteLine("two times tabs");
//        //    string s = "Rahul";
//        //    Console.WriteLine(s);

//        //    Console.WriteLine("enetr user name");
//        //    string username = Console.ReadLine();
//        //    Console.WriteLine("your user name is " + username);

//        //    Console.ReadLine();
//        //}

//        //static void Main()
//        //{
//        //    Console.WriteLine("Enter first name");
//        //    string firstname = Console.ReadLine();

//        //    Console.WriteLine("Enter Last name");
//        //    string lastname = Console.ReadLine();

//        //    Console.WriteLine("Your Full name is :" + firstname + " " + lastname);
//        //    string fullname = "Your Full name is :" + firstname + " " + lastname;
//        //    Console.WriteLine("Your Full name is :{0} {1}", firstname, lastname);

//        //    Console.WriteLine("Enter salary");
//        //    int sal = Convert.ToInt32(Console.ReadLine());
//        //    Console.WriteLine("your salary is :{0}", sal);

//        //    Console.ReadLine();
//        //}

//        //static void Main()
//        //{
//        //    //sum of the  three digits
//        //    Console.WriteLine("enet the three digit number");
//        //    int num = Convert.ToInt32(Console.ReadLine());//351
//        //    int a, b, c;
//        //    a = num % 10;//1
//        //    num = num / 10;//35
//        //    b = num % 10;//5
//        //    num = num / 10;//3
//        //    c = num % 10;//3

//        //    int sum = a + b + c;
//        //    Console.WriteLine("sum of three digits:{0}",sum);

//        //    Console.ReadLine();
//        //}
//        //static void Main()
//        //{
//        //    //swapping using third variable
//        //    Console.WriteLine("enter num1");
//        //    int num1 = Convert.ToInt32(Console.ReadLine());//red

//        //    Console.WriteLine("enter num2");
//        //    int num2 = Convert.ToInt32(Console.ReadLine());//blue
//        //    Console.WriteLine("before swapping number num1={0} and num2={1}", num1, num2);
//        //    int temp;//empty
//        //    temp = num1;
//        //    num1 = num2;
//        //    num2 = temp;
//        //    Console.WriteLine("swapped number num1={0} and num2={1}",num1,num2);

           

//        //    Console.ReadLine();
//        //}

//        static void Main()
//        {
//            //swapping using third variable
         
//            Console.ReadLine();
//            swap();
//            Program obj = new Program();
//            obj.swapNonStatic();
//            //outside class --how to call static 
//            //Program.Main();
//        }

//        public static void swap() {
//            Console.WriteLine("enter num1");
//            int num1 = Convert.ToInt32(Console.ReadLine());//red

//            Console.WriteLine("enter num2");
//            int num2 = Convert.ToInt32(Console.ReadLine());//blue
//            Console.WriteLine("before swapping number num1={0} and num2={1}", num1, num2);
//            num1 = num1 + num2;//3+2//5
//            num2 = num1 - num2;//3
//            num1 = num1 - num2;//2
//            Console.WriteLine("swapped number num1={0} and num2={1}", num1, num2);
//        }


//        public void swapNonStatic()
//        {
//            swap();
//            swapNonStaticNew();
//            Console.WriteLine("enter num1");
//            int num1 = Convert.ToInt32(Console.ReadLine());//red

//            Console.WriteLine("enter num2");
//            int num2 = Convert.ToInt32(Console.ReadLine());//blue
//            Console.WriteLine("before swapping number num1={0} and num2={1}", num1, num2);
//            num1 = num1 + num2;//3+2//5
//            num2 = num1 - num2;//3
//            num1 = num1 - num2;//2
//            Console.WriteLine("swapped number num1={0} and num2={1}", num1, num2);
             
//        }


//        public void swapNonStaticNew()
//        {
//            swap();
//            Console.WriteLine("enter num1");
//            int num1 = Convert.ToInt32(Console.ReadLine());//red

//            Console.WriteLine("enter num2");
//            int num2 = Convert.ToInt32(Console.ReadLine());//blue
//            Console.WriteLine("before swapping number num1={0} and num2={1}", num1, num2);
//            num1 = num1 + num2;//3+2//5
//            num2 = num1 - num2;//3
//            num1 = num1 - num2;//2
//            Console.WriteLine("swapped number num1={0} and num2={1}", num1, num2);
//        }
//    }

//    class MySample {

//        public void Call() { 
//        //static Method 
//            Program.swap();

//            Program obj = new Program();
//            obj.swapNonStatic();
        
//        }

    
//    }


//}
