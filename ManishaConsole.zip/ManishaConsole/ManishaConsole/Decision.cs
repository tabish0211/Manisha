﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManishaConsole
{
    public class Decision
    {
        public void IfDemo() {

            int x = 1, y = 2,z=3;
            if (x > y)
            {
                Console.WriteLine("x is larger");
            }
            else if (z>x)
            {
                Console.WriteLine("hi");
            }
            else
            {
                Console.WriteLine("y is larger");
            }
        }

        public void CondtionalOperator()
        {

            int x = 1, y = 2, z = 3;
            int res = x > y ? x : y;
        }

        public void SwitchCase()
        {

            Console.WriteLine("enter choice");
            int choice = Convert.ToInt32(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    Console.WriteLine("Hi");
                    break;

                case 2:
                    Console.WriteLine("bye");
                    break;

                case 3:
                    Console.WriteLine("Hello");
                    break;
                default:
                    Console.WriteLine("Its default");
                    break;
            }

            
        }

    }
}
