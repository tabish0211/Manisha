﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManishaConsole
{
    class ObjectConcept
    {

        private static int counter = 0;
        static void Main(string[] args)
        {
           //Decisons
            Decision obj = new Decision();
           // obj.IfDemo();
            obj.SwitchCase();

            //incr -decr demo
            //var obj = new IncrDecrDemo();
            //obj.demo_PostIncr();
            //obj.demo_PreIncr();


            //Properties Demo
           // var obj = new PropertiesDemo();
            //Console.WriteLine("enetr id");
            //int id = Convert.ToInt32(Console.ReadLine());

            //obj.ID = 101;
            //Console.WriteLine(obj.ID);

           // obj.set(id);
            //Console.WriteLine(obj.get());

         
           
            //Mysample obj = new Mysample();
            //(new Mysample()).Add();
            //(new Mysample()).Sub();

           // Mysample obj = new Mysample();
            //obj.Add();
            //int x, y,res;//local variable---inside method--Main();
            //x = 1; y = 2;//it must be initialised before sending as ref
            //obj.Sub(x, y);//Actual argument 

           ///int res= obj.SumoftwoNumbers();
           //Console.WriteLine(res);

           // obj.SubRef(ref x,ref y);
            //obj.Sub(x, y, out res);

            //Mysample obj = new Mysample();
            //obj.NullableDemo();
           // obj.OptionalParameterDemo(2);

            //obj.NamedParameterDemo(y:2, x:3);
            //var obj = new ABCDEFGHIJKLMNIOPQWERTTGGGGGVVVVN();
            //obj.show();
            Console.ReadLine();

        }
    }

    class Mysample
    {


        //default method
        public void Add()
        {
            

        }
        //formal argument
        public void Sub(int x, int y,out int res)
        {
            res = x - y;
              

        }

        public void SubRef(ref int x,ref int y)
        {

            //x,y scope is Sub()

        }

        public int SumoftwoNumbers()
        {
            int res = 1 + 2;

            return res;
        }

        public void NullableDemo() {

            int? ID = null;
            int? IdColon = ID ?? 0;
            Console.WriteLine(IdColon);

        }


        public void OptionalParameterDemo(int x=2,int y=1)
        {
            int sum = x + y;
            Console.WriteLine(x+y);

        }

        public void NamedParameterDemo(int x, int y)
        {
            x = 5;
            y = 8;
            int sum = x + y;
            Console.WriteLine(x + y);

        }


        
    }


    class ABCDEFGHIJKLMNIOPQWERTTGGGGGVVVVN {


        public void show() {

            Console.WriteLine("var Demo");
        
        }

    }

}
